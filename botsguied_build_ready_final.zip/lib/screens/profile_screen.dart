import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'payment_screen.dart';

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(padding: EdgeInsets.all(12), children: [
      ListTile(title: Text('Jane Doe'), subtitle: Text('Gaborone')),
      ListTile(title: Text('dark_mode'.tr()), trailing: Switch(value: false, onChanged: (_){},)),
      ListTile(title: Text('language'.tr()), subtitle: Text('english'.tr())),
      ListTile(title: Text('Subscribe (Premium)'), subtitle: Text('Unlock notifications and premium features'), onTap: () { Navigator.push(context, MaterialPageRoute(builder: (_) => PaymentScreen())); }),
    ]);
  }
}
