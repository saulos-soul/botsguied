import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import '../services/payment_service.dart';

class PaymentScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('Subscribe (Premium)').tr()), body: Padding(
      padding: EdgeInsets.all(12),
      child: Column(children: [
        ElevatedButton(onPressed: () => PaymentService.openOrangeMoneyPayment('1', 49.99), child: Text('Pay with Orange Money')),
        ElevatedButton(onPressed: () => PaymentService.openSmegaPayment('1', 49.99), child: Text('Pay with Smega')),
        ElevatedButton(onPressed: () => PaymentService.openMyZakaPayment('1', 49.99), child: Text('Pay with MyZaka')),
      ]),
    ));
  }
}
