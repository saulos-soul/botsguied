import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:easy_localization/easy_localization.dart';

class AddListingScreen extends StatefulWidget {
  @override
  State<AddListingScreen> createState() => _AddListingScreenState();
}

class _AddListingScreenState extends State<AddListingScreen> {
  final _title = TextEditingController();
  final _category = TextEditingController();
  final _address = TextEditingController();
  bool _saving = false;

  Future<void> _save() async {
    if (_title.text.isEmpty) return;
    setState(() => _saving = true);
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('my_listings') ?? '[]';
    final list = jsonDecode(raw);
    list.add({'title': _title.text, 'category': _category.text, 'address': _address.text});
    await prefs.setString('my_listings', jsonEncode(list));
    setState(() => _saving = false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('saved_ok'.tr())));
  }

  @override
  Widget build(BuildContext context) {
    return Padding(padding: EdgeInsets.all(12), child: Column(children: [
      TextField(controller: _title, decoration: InputDecoration(labelText: 'Title')),
      TextField(controller: _category, decoration: InputDecoration(labelText: 'Category')),
      TextField(controller: _address, decoration: InputDecoration(labelText: 'Address')),
      SizedBox(height:12),
      ElevatedButton(onPressed: _saving?null:_save, child: Text('save_draft'.tr())),
    ]));
  }
}
