// Seed Firestore (call SeedFirestore.run() after Firebase initialized)
import 'package:cloud_firestore/cloud_firestore.dart';
class SeedFirestore {
  static final _db = FirebaseFirestore.instance;
  static Future<void> run() async {
    final events = _db.collection('events');
    final snap = await events.limit(1).get();
    if (snap.docs.isEmpty) {
      await events.add({'title':'Gaborone Food & Music Festival','location':'Gaborone Park','date':DateTime.now().toIso8601String()});
    }
  }
}
