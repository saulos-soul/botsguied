BotsGuied - Build-ready project. See BUILD_INSTRUCTIONS.txt
