import 'package:url_launcher/url_launcher.dart';

class PaymentService {
  static Future<void> openOrangeMoneyPayment(String orderId, double amount) async {
    final url = Uri.parse('https://example.com/pay/orange_money?order=$orderId&amount=$amount');
    if (await canLaunchUrl(url)) await launchUrl(url, mode: LaunchMode.externalApplication);
  }
  static Future<void> openSmegaPayment(String orderId, double amount) async {
    final url = Uri.parse('https://example.com/pay/smega?order=$orderId&amount=$amount');
    if (await canLaunchUrl(url)) await launchUrl(url, mode: LaunchMode.externalApplication);
  }
  static Future<void> openMyZakaPayment(String orderId, double amount) async {
    final url = Uri.parse('https://example.com/pay/myzaka?order=$orderId&amount=$amount');
    if (await canLaunchUrl(url)) await launchUrl(url, mode: LaunchMode.externalApplication);
  }
}
