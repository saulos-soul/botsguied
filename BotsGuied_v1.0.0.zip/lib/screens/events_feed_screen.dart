import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class EventsFeedScreen extends StatefulWidget {
  @override
  State<EventsFeedScreen> createState() => _EventsFeedScreenState();
}

class _EventsFeedScreenState extends State<EventsFeedScreen> {
  bool _promptChecked = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_promptChecked) {
      _promptOnce();
      _promptChecked = true;
    }
  }

  Future<void> _promptOnce() async {
    final prefs = await SharedPreferences.getInstance();
    final seen = prefs.getBool('seen_login_prompt') ?? false;
    if (!seen) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        showDialog(context: context, builder: (_) => AlertDialog(
          title: Text('Welcome'),
          content: Text('You can browse for free. Sign in once to unlock notifications and save preferences.'),
          actions: [TextButton(onPressed: () { prefs.setBool('seen_login_prompt', true); Navigator.pop(context); }, child: Text('OK'))],
        ));
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text('Events feed (sample)'), SizedBox(height:12), Text('Offline & Firebase hybrid enabled')])));
  }
}
