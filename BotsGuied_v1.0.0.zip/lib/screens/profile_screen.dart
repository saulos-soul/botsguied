import 'package:flutter/material.dart';
import 'payment_screen.dart';

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(padding: EdgeInsets.all(12), children: [
      ListTile(title: Text('Jane Doe'), subtitle: Text('Gaborone')),
      ListTile(title: Text('Subscribe (Premium)'), subtitle: Text('Unlock notifications and premium features'), onTap: () { Navigator.push(context, MaterialPageRoute(builder: (_) => PaymentScreen())); }),
    ]);
  }
}
