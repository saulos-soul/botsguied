BotsGuied - Ready project for Codemagic. Upload to GitHub then build on Codemagic.

Package: com.botsguied.app
Version: 1.0.0+1
Flutter: 3.19 (stable)
