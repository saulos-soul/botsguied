import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProfileScreen extends StatefulWidget {
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _dark = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _dark = prefs.getBool('dark_mode') ?? false);
  }

  Future<void> _toggle(bool v) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('dark_mode', v);
    setState(() => _dark = v);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(padding: EdgeInsets.all(12), child: Column(children: [
      ListTile(leading: Icon(Icons.person), title: Text('Guest User'), subtitle: Text('Gaborone')),
      SwitchListTile(value: _dark, onChanged: _toggle, title: Text('Dark Mode')),
      SizedBox(height:12),
      ElevatedButton(onPressed: () {}, child: Text('Sign in (one-time)')),
    ]));
  }
}
