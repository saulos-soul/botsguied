import 'package:flutter/material.dart';

class ExploreScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.place, size:64), SizedBox(height:12), Text('Explore places and entertainment'),])));
  }
}
