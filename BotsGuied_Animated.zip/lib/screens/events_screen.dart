import 'package:flutter/material.dart';

class EventsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Padding(padding: EdgeInsets.all(16), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.music_note, size:64), SizedBox(height:12), Text('Events coming soon')])));
  }
}
