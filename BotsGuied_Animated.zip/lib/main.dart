import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/home_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  final prefs = await SharedPreferences.getInstance();
  final dark = prefs.getBool('dark_mode') ?? false;
  runApp(BotsApp(initialDark: dark));
}

class BotsApp extends StatefulWidget {
  final bool initialDark;
  BotsApp({required this.initialDark});

  @override
  State<BotsApp> createState() => _BotsAppState();
}

class _BotsAppState extends State<BotsApp> {
  late bool _isDark;

  @override
  void initState() {
    super.initState();
    _isDark = widget.initialDark;
  }

  void _toggleTheme(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('dark_mode', value);
    setState(() => _isDark = value);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BotsGuied',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(brightness: Brightness.light, primarySwatch: Colors.blue),
      darkTheme: ThemeData(brightness: Brightness.dark, primarySwatch: Colors.blue),
      themeMode: _isDark ? ThemeMode.dark : ThemeMode.light,
      home: SplashScreen(onFinish: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => HomeScreen(onToggleTheme: _toggleTheme, isDark: _isDark)))),
    );
  }
}

class SplashScreen extends StatefulWidget {
  final VoidCallback onFinish;
  SplashScreen({required this.onFinish});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _opacity;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: Duration(milliseconds: 1600));
    _opacity = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(parent: _controller, curve: Curves.easeIn));
    _scale = Tween<double>(begin: 0.9, end: 1.05).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    _controller.forward();
    Future.delayed(Duration(seconds: 3), () => widget.onFinish());
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF003366),
      body: Center(
        child: AnimatedBuilder(
          animation: _controller,
          builder: (_, __) => Opacity(
            opacity: _opacity.value,
            child: Transform.scale(scale: _scale.value, child: Text('BotsGuied', style: TextStyle(color: Colors.white, fontSize: 42, fontWeight: FontWeight.bold))),
          ),
        ),
      ),
    );
  }
}
